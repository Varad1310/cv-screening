# Automated-Resume-Screening-System
A web app to help employers by analysing resumes and CVs, surfacing candidates that best match the position and filtering out those who don't.

# Description
Used recommendation engine techniques such as KNN, content based filtering and ensemble  job description with multiple resumes.

# Packages
Gensim

Numpy==1.11.3

Pandas

Sklearn

Python 3.6.0 |Anaconda 4.3.0 (64-bit)
# Run Method
Run file app.py in resumizer-master

run command

python app.py

# Made By
CodeByte
